#pragma once

int matrix(int SIDE, FILE* fp);
